//var latit=50.276705;
//var longit=18.6899785;


function LocateMe()
{
	if(navigator.geolocation)
	{
		navigator.geolocation.getCurrentPosition(onSuccess, onError, { maximumAge: 0, timeout: 30000, enableHighAccuracy: true});
	}
}

function onSuccess(loc)
{
	
	document.getElementById("accuracy").innerHTML = "accuracy: " + loc.coords.accuracy + "m,";
	document.getElementById("location").innerHTML = "location: " + loc.coords.latitude + " ; " + loc.coords.longitude;
	latit = loc.coords.latitude;
	longit = loc.coords.longitude;
	map = L.map('map').setView([loc.coords.latitude, loc.coords.longitude], 13);
		L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
		attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
		maxZoom: 18,
		id: 'mapbox.streets',
		accessToken: 'pk.eyJ1IjoiZ3BpbGVja2kiLCJhIjoiY2prM3dqY3Y4MTdvcjNybWx2Zjc2YXNiNCJ9.bT1mmUdbPZBufUlJkCG95Q'
	}).addTo(map)
	
	map.addControl( new L.Control.Search({
		url: 'http://nominatim.openstreetmap.org/search?format=json&q={s}',
		jsonpParam: 'json_callback',
		propertyName: 'display_name',
		propertyLoc: ['lat','lon'],
	//	marker: L.circleMarker([0,0],{radius:30}),
		marker: L.circleMarker([50.276705, 18.6899785], {
			color: 'red',
			fillColor: '#f03',
			fillOpacity: 0.5,
			radius: 50
			}),
		autoCollapse: true,
		autoType: false,
		minLength: 2
	}) );
	
/*	var circle = L.circle([50.276705, 18.6899785], {
    color: 'red',
    fillColor: '#f03',
    fillOpacity: 0.5,
    radius: 500
}).addTo(mymap);*/
	
	map.setView({ center: view });
}

function onError(geoPositionError)
{
	switch(geoPositionError.code)
	{
		case 0: //UNKNOWN_ERROR
			alert('Nieznany blad');
			break;
		case 1: //PERMISSION_DENIED
			alert('Uzytkownik nie wyrazil zgody na udostepnienie lokalizacji');
			break;
		case 2: //POSITION_UNAVAILABLE
			alert('Niemozna ustalic lokalizacji');
			break;
		case 3: //TIMEOUT
			alert('Przekroczono czas oczekiwania na ustalenie lokalizacji');
			break;
		default:
	}
}

function sprawdz()
{
	var liczba = document.getElementById("pole").value;

	if(liczba>0) document.getElementById("wynik").innerHTML="dodatnia";
	else if(liczba<0) document.getElementById("wynik").innerHTML="ujemna";
	else if(liczba==0) document.getElementById("wynik").innerHTML="zero";
	else if(liczba=="") document.getElementById("wynik").innerHTML="puste pole!";
	else document.getElementById("wynik").innerHTML="to nie jest liczba!";
}









//	alert('latitude = ' + latit + ' ; longitude = ' + longit);
//alert('latitude = ', + loc.coords.latitude + ' ; longitude = ' + loc.coords.longitude);
//var map = L.map('map').setView([51.505, -0.09], 13);
/*var map = L.map('map').setView([latit, longit], 13);
L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
	attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
	maxZoom: 18,
	id: 'mapbox.streets',
	accessToken: 'pk.eyJ1IjoiZ3BpbGVja2kiLCJhIjoiY2prM3dqY3Y4MTdvcjNybWx2Zjc2YXNiNCJ9.bT1mmUdbPZBufUlJkCG95Q'
}).addTo(map);
							
map.addControl( new L.Control.Search({
	url: 'http://nominatim.openstreetmap.org/search?format=json&q={s}',
	jsonpParam: 'json_callback',
	propertyName: 'display_name',
	propertyLoc: ['lat','lon'],
	marker: L.circleMarker([0,0],{radius:30}),
	autoCollapse: true,
	autoType: false,
	minLength: 2
}) );


*/






/*	var mymap = L.map('mapid').setView([51.505, -0.09], 13);
	L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
    attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
    maxZoom: 18,
    id: 'mapbox.streets',
    accessToken: 'pk.eyJ1IjoiZ3BpbGVja2kiLCJhIjoiY2prM3dqY3Y4MTdvcjNybWx2Zjc2YXNiNCJ9.bT1mmUdbPZBufUlJkCG95Q'
}).addTo(mymap);



	var marker = L.marker([51.5, -0.09]).addTo(mymap);

	var circle = L.circle([51.508, -0.11], {
    color: 'red',
    fillColor: '#f03',
    fillOpacity: 0.5,
    radius: 500
}).addTo(mymap);

	var polygon = L.polygon([
    [51.509, -0.08],
    [51.503, -0.06],
    [51.51, -0.047]
]).addTo(mymap);

	marker.bindPopup("<b>Hello world!</b><br>I am a popup.").openPopup();
circle.bindPopup("I am a circle.");
polygon.bindPopup("I am a polygon.");

	var popup = L.popup()
    .setLatLng([51.5, -0.09])
    .setContent("I am a standalone popup.")
    .openOn(mymap);

	function onMapClick(e) {
    alert("You clicked the map at " + e.latlng);
}

mymap.on('click', onMapClick);

var popup = L.popup();

function onMapClick(e) {
    popup
        .setLatLng(e.latlng)
        .setContent("You clicked the map at " + e.latlng.toString())
        .openOn(mymap);
}

mymap.on('click', onMapClick);*/